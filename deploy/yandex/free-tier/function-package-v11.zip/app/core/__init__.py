"""Core module"""
